import React, { Component } from 'react';
import Header from '../components/Layout/Header/Header';
import Footer from '../components/Layout/Footer/Footer';
import SiteBreadcrumb from '../components/Common/Breadcumb';
import Brand from '../components/Common/Brand';
import CaseDetailsMain from '../components/CaseStudy/CaseDetailsMain';


class CaseDetails extends Component {

    render() {

        return (
            <React.Fragment>
                <Header />
                <main>
                    {/* breadcrumb-area-start */}
                    <SiteBreadcrumb pageTitle="Case Details" />
                    {/* breadcrumb-area-start */}
                    {/* Case Details */}
                    <CaseDetailsMain />
                    {/* Case Details */}
                    {/* brand-area-start */}
                    <Brand />
                    {/* brand-area-end */}
                </main>
                <Footer />
            </React.Fragment>

        );
    }
}


export default CaseDetails;