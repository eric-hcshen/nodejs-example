import React from 'react';
import TabDefault from '../Elements/Tab/TabDefault';

const Project = () => {
    return (
        <TabDefault />
    );
}

export default Project;