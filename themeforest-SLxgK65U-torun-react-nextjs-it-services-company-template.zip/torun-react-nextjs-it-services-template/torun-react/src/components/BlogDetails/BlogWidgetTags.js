import React, { Component } from 'react';

class BlogWidgetTags extends Component {

    render() {
        return (
            <main>
                <div className="widget mb-40">
                    <div className="widget-title-box mb-30">
                        <span className="animate-border"></span>
                        <h3 className="widget-title">Instagram Feeds</h3>
                    </div>
                    <div className="tag">
                        <a href="#">Popular</a>
                        <a href="#">desgin</a>
                        <a href="#">usability</a>
                        <a href="#">develop</a>
                        <a href="#">consult</a>
                        <a href="#">icon</a>
                        <a href="#">HTML</a>
                        <a href="#">ux</a>
                        <a href="#">business</a>
                        <a href="#">kit</a>
                        <a href="#">keyboard</a>
                        <a href="#">tech</a>
                    </div>
                </div>
            </main>
        );
    }
}


export default BlogWidgetTags;

