/**
 * Created by KING on 2014/12/12.
 *
 * ch01.hello-world.js
 */
console.log("Hello World!");