/**
 * Created by KING on 2014/12/23.
 *
 * ch01.format-argument.js
 */
console.log("%s", "argument");
console.log("%s");
console.log("%d", 8);
console.log("%d");
console.log("%8s");
console.log("%8d");
console.log("%8s", "%8s");
console.log("%8d", 8);