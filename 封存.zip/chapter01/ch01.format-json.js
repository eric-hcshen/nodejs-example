/**
 * Created by KING on 2014/12/21.
 *
 * ch01.format-json.js
 */
console.log("%j", {OS:"Windows",Version:"7.1",Language:["English","Chinese"]});
var v_json = {
    OS:"Windows",
    Version:"7.1",
    Language:["English","Chinese"]
}
console.log("%j", v_json);
