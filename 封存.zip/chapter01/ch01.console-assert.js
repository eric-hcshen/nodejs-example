/**
 * Created by KING on 2015/1/15.
 *
 * ch01.console-assert.js
 */
var i=0;
var j=1;
console.assert(i==0, "OK");
console.assert(i==j, "throw an exception");