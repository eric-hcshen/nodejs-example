/**
 * Created by KING on 2015/1/6.
 *
 * ch01.obj-dir.js
 */
console.dir(123);
console.dir("abc");
console.dir({"abc":123});
console.dir(1+2*3+1);
console.dir(console);