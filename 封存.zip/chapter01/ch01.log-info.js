/**
 * Created by KING on 2014/12/20.
 *
 * ch01.log-info.js
 */
console.log("Node.js - console.log() 方法");
console.info("Node.js - console.info() 方法");