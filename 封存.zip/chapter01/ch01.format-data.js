/**
 * Created by KING on 2014/12/20.
 *
 * ch01.format-data.js
 */
console.log(8)
console.log(8, 8+0.8);
console.log("%d", 8, 8.8);
console.log("%d-%d", 8.8, 8.0);
console.log("%d", 8+8, 8-8, 8*8, 8/8);
console.log("%d", "8+8");
console.log(8/0);