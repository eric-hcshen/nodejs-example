/**
 * Created by KING on 2014/12/22.
 *
 * ch01.format-logic.js
 */
var a=0;
var b=1;
console.log(a==b);  // 使用比較運算表，輸出false
console.log(a>=b);  // 使用比較運算表，輸出false
console.log(a<=b);  // 使用比較運算表，輸出true
console.log(a==0 && b==1);    // 使用邏輯運算表，輸出true