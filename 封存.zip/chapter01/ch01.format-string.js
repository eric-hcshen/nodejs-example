/**
 * Created by KING on 2014/12/20.
 *
 * ch01-format-string.js
 */
console.log("%s", "This is a format-string Note.js Program.");  /* %s - String */
console.log("%s %s %s", "You can", "connect", "several strings.");  /* connect strings */
console.log("%s", "You can", "connect", "several strings.");
console.log("%s:%s", "object", "string");
console.log("%s-%s", "object", "string");
console.log("%");
console.log("%%");  /* single percent sign ('%'). This does not consume an argument. */