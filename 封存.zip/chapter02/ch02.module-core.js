/**
 * Created by king on 15-2-12.
 *
 * ch02.module-core.js
 */
var http = require('http');	// TODO: 加載核心模組'http'