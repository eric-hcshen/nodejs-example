/**
 * Created by king on 15-3-6.
 *
 * index.js
 */
var cal = require('./lib/calculate');