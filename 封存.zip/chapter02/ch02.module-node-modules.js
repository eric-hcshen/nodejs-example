/**
 * Created by king on 15-2-12.
 *
 * ch02.module-node-modules.js
 */
console.log();
console.log('---列印paths屬性---');
console.log(module.paths);
console.log('---列印完成---');
console.log();