/**
 * Created by king on 15-3-22.
 *
 * ch05.process-sysinfo-node.js
 */
console.info("------   Process System Info   ------");
console.info();
console.info('Node.js版本號:');
console.info(process.version);
console.info();
console.info('Node.js版本屬性:');
console.info(process.versions);
console.info();
console.info("------   Process System Info   ------");