/**
 * Created by king on 15-3-22.
 *
 * ch05.process-sysinfo-shell.js
 */
console.info("------   Process System Info   ------");
console.info();
console.info('指向現在shell的環境變數:');
console.info(process.env);
console.info();
console.info("------   Process System Info   ------");