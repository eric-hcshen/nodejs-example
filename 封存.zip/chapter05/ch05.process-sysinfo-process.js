/**
 * Created by king on 15-3-22.
 *
 * ch05.process-sysinfo-process.js
 */
console.info("------   Process System Info   ------");
console.info();
console.info('執行現在處理程序可執行檔案的絕對路徑:');
console.info(process.execPath);
console.info();
console.info('現在處理程序的命令行參數數組:');
console.info(process.argv);
console.info();
console.info("------   Process System Info   ------");