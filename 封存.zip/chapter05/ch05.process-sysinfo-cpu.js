/**
 * Created by king on 15-3-22.
 *
 * ch05.process-sysinfo-cpu.js
 */
console.info("------   Process System Info   ------");
console.info();
console.info('現在系統平台:');
console.info(process.platform);
console.info();
console.info('現在CPU架構:');
console.info(process.arch);
console.info();
console.info("------   Process System Info   ------");