/**
 * Created by king on 15-3-22.
 *
 * ch05.process-sysinfo-pid.js
 */
console.info("------   Process System Info   ------");
console.info();
console.info('現在處理程序id:');
console.info(process.pid);
console.info();
console.info('現在處理程序名稱:');
console.info(process.title);
console.info();
console.info("------   Process System Info   ------");