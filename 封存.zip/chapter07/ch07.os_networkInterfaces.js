/**
 * Created by king on 15-4-15.
 *
 * ch07.os_networkInterfaces.js
 */
console.info("------   OS os_networkInterfaces()   ------");
console.info();
var os = require('os'); // TODO: 引入OS模組
var networkInterfaces = os.networkInterfaces();
console.info(networkInterfaces);
console.info();
console.info("------   OS os_networkInterfaces()   ------");