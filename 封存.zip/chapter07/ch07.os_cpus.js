/**
 * Created by king on 15-4-15.
 *
 * ch07.os_cpus.js
 */
console.info("------   OS cpus()   ------");
console.info();
var os = require('os'); // TODO: 引入OS模組
var cpus = os.cpus();
console.info(cpus);
console.info();
console.info("------   OS cpus()   ------");