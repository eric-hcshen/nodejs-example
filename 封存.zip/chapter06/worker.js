/**
 * Created by king on 15-4-7.
 *
 * ch06.child_process_fork_usage.js worker.js
 */
console.info('This is a child_process.');